import 'package:flutter/material.dart';

abstract class WayColor {
  static const bluePrimary = Color(0xFF102030);
  static const blueSecondary = Color(0xFF2f4050);
  static const grey = Color(0xFF3e454d);
  static const green = Color(0xFF008000);
 
}
